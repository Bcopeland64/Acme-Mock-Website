#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      Brandon Copeland
#
# Created:     01/05/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------
from Questions import Question
import random

question_prompts = [


    "Have you (or anyone in your family) ever \n(a) broken your arm/leg? \n(b) felt your arm/leg? \n(c) caught your arm/leg?\n\n",
    "Do you often \n(a)catch colds or the flu? \n(b) give colds or the flu? \n(c) have colds or the flue?\n\n",
    "I went to the library last week \n(a) to find a book. \n(b) to discuss business. \n(c) to imporve my English.\n\n",
    "She always loves \n(a) going to the store \n(b) go to the store \n(c) gone to the store\n\n",
    "In 1999, she \n(a) went to Egypt. \n(b) had gone to Egypt. \n(c) had went to Egypt.\n\n",
    "If you’d written earlier, I’d have known when you \n(a) will want to go on holiday. \n(b) would want to go on holiday. \n(c) wanted to go on holiday.\n\n",
    "How many eggs have we got? \n(a)They're no in the fridge. \n(b)Not too many \n(c)Not too much.\n\n",
    "We \n(a) can be able to be millionaires one day \n(b) will have to be millionaires one day \n(c) could be millionaires one day.\n\n",
    "He was fined by the police for driving too \n(a) fastly \n(b) speedy \n(c) fast.\n\n",
    "What are you doing? I \n(a) tried to find my watch! \n(b) am trying to find my watch! \n(c) have tried to find my watch!\n\n"

]


questions = [

    Question(question_prompts[0], "a"),
    Question(question_prompts[1], "a"),
    Question(question_prompts[2], "a"),
    Question(question_prompts[3], "a"),
    Question(question_prompts[4], "a"),
    Question(question_prompts[5], "c"),
    Question(question_prompts[6], "b"),
    Question(question_prompts[7], "c"),
    Question(question_prompts[8], "c"),
    Question(question_prompts[9], "b"),

]

def run_test(questions):
    score = 0
    for question in questions:
        answer = input(question.prompt)
        if answer == question.answer:
            score += 1
    print("You got " + str(score) + "/" + str(len(questions)) + "Correct")

run_test(questions)

