#-------------------------------------------------------------------------------
# Name:        module2
# Purpose:
#
# Author:      Brandon Copeland
#
# Created:     01/05/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------

class Question:
    def __init__(self, prompt, answer):
        self.prompt = prompt
        self.answer = answer

