from urllib.request import urlopen
from bs4 import BeautifulSoup
import ssl

url = "http://py4e-data.dr-chuck.net/comments_245727.html"

request = urlopen(url)
soup = BeautifulSoup(request,"lxml")

soup_new = soup.findAll("span", { "class" : "comments" })
sum = 0

for item in soup_new:
    sum = sum + int(item.text)

print(sum)
