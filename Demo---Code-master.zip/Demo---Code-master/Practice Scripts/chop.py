def first_last(t):
	del t[0, -1]
