fhand = open('Beowulf.txt')
inp = fhand.read()
print(len(inp))

print(inp.upper())
