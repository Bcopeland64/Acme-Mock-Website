fhand = open('Beowulf.txt')
for line in fhand:
	line = line.rstrip()
	if line.startswith('We'): continue
	words = line.split()
	print(words)
	

