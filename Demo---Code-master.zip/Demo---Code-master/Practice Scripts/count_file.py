fhand = open('Beowulf.txt')
count = 0
for i in fhand:
	count = count + 1
	print("Count equals:", count)
	
print("Total Count:", count)

	
