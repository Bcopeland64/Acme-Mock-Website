fhand = open('Beowulf.txt')
count = 0
for line in fhand:
	line = line.strip()
	if line.startswith('We'):
		print(line)
	
