print(5 + 3)
print(9 - 1)
print(16 / 2)
print(4 * 2)
