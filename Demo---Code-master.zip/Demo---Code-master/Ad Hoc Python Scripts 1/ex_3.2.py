#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      HO0me
#
# Created:     10/06/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------
try:
    grade = input("Enter Score: ")
    score = float(grade)
    if (score >= 1.0):
        print("Your number is too high")
        exit()
    elif (score >= 0.9):
        print("You earned a(n): A")
    elif (score >= 0.8):
        print("You earned a(n): B")
    elif (score >= 0.7):
        print("You earned a(n): C")
    elif (score >= 0.6):
        print("You earned a(n): D")
    else:
        print("You earned a(n): F")
except:
    print("Please enter a lower number")
    exit()