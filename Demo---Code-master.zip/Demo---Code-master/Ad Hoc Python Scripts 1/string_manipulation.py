fruit = 'banana'
index = 0

while index < len(fruit):
    x = fruit[index]
    print(index, x)
    index = index + 1

fruit = 'banana'
for letter in fruit:
    print(letter)

word = 'banana'
count = 0
for letter in word:
    if letter == 'a':
        count = count + 1
print(count)

x = 'From marquard@uct.ac.za'
print(x[14:17])