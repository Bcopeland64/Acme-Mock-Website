animals = ["Bears", "Tigers", "Lions"]
for animal in animals:
  print(animal.title() + " would make awesome pets" + "\n")
  print(animal.title() + " would maybe eat me if I turned my back on them" + "\n")
  print(animal.title() + " will remain king of the jungle" + "\n")
print("Any of these animals would make a kingly pet!" + "\n")
 
