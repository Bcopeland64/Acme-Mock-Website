def hello():
    print('Howdy!')
    print('Howdy!!!')
    print('Hello There.')
    
hello()
hello()
hello()
