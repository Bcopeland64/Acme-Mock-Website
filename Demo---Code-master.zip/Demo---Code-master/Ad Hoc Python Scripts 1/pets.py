pets = ['dog', 'cat', 'parrot', 'gold fish', 'cat', 'lizard', 'cat']
print(pets)

while 'cat' in pets:
    pets.remove('cat')
    
print(pets)
