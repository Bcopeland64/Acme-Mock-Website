#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      HO0me
#
# Created:     23/05/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import turtle

bob = turtle.Turtle()
print(bob)
for i in range(4):
    bob.fd(100)
    bob.lt(90)

turtle.mainloop()