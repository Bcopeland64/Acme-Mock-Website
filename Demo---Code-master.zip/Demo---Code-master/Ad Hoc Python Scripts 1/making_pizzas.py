import pizza

pizza.make_pizza('16', 'pepperoni')
pizza.make_pizza('18', 'mushroom')
