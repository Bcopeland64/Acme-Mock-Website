table = input("How many people will be joining you today? ")
if table >= str(8):
    print("Sorry...you'll have to wait 15 minutes.")
else: 
    print("Your table is ready!")
