dinner_guests = ["Malcolm X", "Marcus Garvey", "Bobby Seales"]
print(dinner_guests)

print(len(dinner_guests))

