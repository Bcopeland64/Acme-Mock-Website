def my_function():
  print("Hello from a function")
  
my_function()
