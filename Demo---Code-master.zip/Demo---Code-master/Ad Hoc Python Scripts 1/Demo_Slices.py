pizzas = ["Pepperoni", "Sausage", "Cheese", "Veggie", "Alfredo", "Italiano", "Extravaganza", "Chicken", "Beef"]
print(pizzas)

print("The first three items in the list are:")
for pizza in pizzas[0:3]:
	print(pizza.title())
	
print("The middle three items in the list are:")
for pizza in pizzas[3:6]:
	print(pizza.title())
	
print("The last three items in the list are:")
for pizza in pizzas[6:9]:
	print(pizza.title())
	
friend_pizzas = ["Cheese", "Sausage", "Cheese", "Veggie", "Italiano"]
friend_pizzas.append("Beef")
print("My friend's favorite pizzas are:")
print(friend_pizzas)

pizzas.append("Turkey")
friend_pizzas.append("Stromboli")
print("My favorite pizzas are:")
for pizza in pizzas:
	print(pizza.title())

print("My friend's favorite pizzas are:")
for pizza in friend_pizzas:
	print(pizza.title())
