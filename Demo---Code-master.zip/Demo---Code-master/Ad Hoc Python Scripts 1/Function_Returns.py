def my_function(x):
  return 5 * x
  
print(my_function(3))
print(my_function(5))
print(my_function(9))
print(my_function(4))
print(my_function(7))
print(my_function(2))
print(my_function(1))
print(my_function(6))
  
