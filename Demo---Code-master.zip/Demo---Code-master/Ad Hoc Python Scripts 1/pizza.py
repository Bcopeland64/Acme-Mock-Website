def make_pizza(size, *toppings):
    print("\nMaking a(n) " + str(size) + "-inch pizza with the following toppings:")
    for topping in toppings:
        print("- " + topping)
    
make_pizza('16', 'pepperoni')
make_pizza('14', 'mushrooms', 'green peppers', 'onions', 'sausage')
make_pizza('18', 'extra cheese', 'anchovies', 'beef', 'salami', 'canadian bacon')
make_pizza('12', 'olives', 'grilled chicken', 'alfredo', 'mozarella')

