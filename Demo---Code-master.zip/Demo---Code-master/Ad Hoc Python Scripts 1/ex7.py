#-------------------------------------------------------------------------------
# Name:        module2
# Purpose:
#
# Author:      HO0me
#
# Created:     01/06/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------

formatter = "{}, {}, {}, {}"

print(formatter.format(1, 2, 3, 4))
print(formatter.format("one", "two", "three", "four"))
print(formatter.format(True, False, False, True))
print(formatter.format(formatter, formatter, formatter, formatter))
print(formatter.format("Try your", "Own text here", "Maybe a poem", "Or a song about fear"))

print(formatter.format(5, 6, 7, 8))
print(formatter.format("five", "six", "seven", "eight"))
print(formatter.format(False, True, True, False))
print(formatter.format(formatter, formatter, formatter, formatter))
print(formatter.format("Sweet 16", "Bang it in the disco", "Bang it", "While your mom's frying her chicken in Crisco"))


