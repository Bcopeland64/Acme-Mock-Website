print("Enter your name:")
x = input()
print("Hello, " , x)#000000
