#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      HO0me
#
# Created:     01/06/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------
days = "\nMon\nTue\nWed\nThurs\nFri\nSat\nSun"
months = "\nJan\nFeb\nMar\nApr\nMay\nJune\nJuly\nAug"

print("Here are the days: ", days)
print("Here are the months: ", months)

print("""
There's something going on here.
With the three double quotes.
We'll be able to type as much as we like.
Even four lines if we want, or 5, or 6
""")
