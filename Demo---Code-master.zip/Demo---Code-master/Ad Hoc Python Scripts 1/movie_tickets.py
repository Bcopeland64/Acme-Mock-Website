prompt = "\nWhat is your age? "

if age < 3:
    print("Your ticket is free!"
if age > 10:
    print("Your ticket is 15$")
