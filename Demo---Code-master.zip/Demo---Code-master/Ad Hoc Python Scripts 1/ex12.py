#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      HO0me
#
# Created:     03/06/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------

age = input("How old are you?")
height = input("How tall are you?")
weight = input("How much do you weigh?")
location = input("Where do you live?")
occupation = input("What do you do?")
length = input("How long have you been doing that?")
future = input("What would you like to do in the future?")

print(f"So, you're {age} years old, {height} tall, and {weight} weigh pounds, live in {location}, work as a(n) {occupation}, been doing that for {length} years, and would like to {future} in the future.")