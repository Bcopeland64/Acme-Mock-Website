import os
os.remove("myfile.txt")

import os
if os.path.exists("myfile.txt"):
	os.remove("myfile.txt")
else:
	print("This file does not exist")
