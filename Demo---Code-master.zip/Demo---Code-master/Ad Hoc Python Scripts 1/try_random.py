import random
for i in range(200):
    print(random.randint(1, 200))
