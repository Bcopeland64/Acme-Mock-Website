favorite_person = {'first_name': 'Ata', 'last_name': 'Baaj', 'age': '32', 'origin': 'Syrian'}
print(favorite_person)
print(favorite_person['first_name'])
print(favorite_person['last_name'])
print(favorite_person['age'])
print(favorite_person['origin'])

