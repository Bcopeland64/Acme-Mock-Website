motorcycles = []
motorcycles.append('Honda')
motorcycles.append('Yamaha')
motorcycles.append('Suzuki')
motorcycles.append('KTM')

print(motorcycles)

motorcycles.insert(0, 'Ducati')
print(motorcycles)

del motorcycles[0]
print(motorcycles)

wish_owned = motorcycles.pop(2)
print("The motorcycle that I always wanted to own was a " + wish_owned + "!")
