#this program is designed to show the output of your favorite number
#Also notice how we used the str() command to make Python realize that the number is a string
footballnumber = 64
print("Your favorite number is " + str(footballnumber))

