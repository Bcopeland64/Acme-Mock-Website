#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      HO0me
#
# Created:     14/06/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------

name = input()
print('What is your name?')

if name == 'Alice':
    print('Hi Alice')
else:
    if name != 'Alice':
     print("You're not Alice!")


