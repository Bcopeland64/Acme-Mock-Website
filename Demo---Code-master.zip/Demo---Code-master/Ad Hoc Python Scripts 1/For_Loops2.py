pizzas = ["Pepperoni", "Sausage", "Italiano"]
for pizza in pizzas:
  print(pizza.title())
  print("I love " + pizza.title())
print("I really love different kinds of pizza, and the ones that I mentioned are my favorites. I really love pizza!!!")
