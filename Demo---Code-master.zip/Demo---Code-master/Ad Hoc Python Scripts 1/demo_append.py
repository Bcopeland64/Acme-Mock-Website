f = open("myfile.txt", "x")
f.write("Hello Bilal and welcome to the wonderful world of Python")

