prompt = "\nPlease enter the name of a city you have visited:"
prompt += "\n(Enter 'quit' when you are finished) "


while True:        
    if city == 'quit':
        break
    else:
        print("I'd love to visit " + city.title() + "!")
