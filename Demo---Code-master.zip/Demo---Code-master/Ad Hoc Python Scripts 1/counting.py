current_number = 1
while current_number <= 100:
    print(current_number)
    current_number += 10
