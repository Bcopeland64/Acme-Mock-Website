#Say Hello to all the wonderful people out there!
print("Hello Python People!")
