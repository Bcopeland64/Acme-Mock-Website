def greet_users(names):
    for name in names:
        msg = "Hello, " + name.title() + "!"
        print(msg)

usernames = ['Muhammad', 'Ataa', 'Manal']
greet_users(usernames)
