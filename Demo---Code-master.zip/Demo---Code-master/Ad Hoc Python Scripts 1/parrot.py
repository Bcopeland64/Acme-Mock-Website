message = input("Tell me something, and I'll repeat it back to you: ")
message += "\nEnter 'quit' to end the program. "

active = True
while active:
    message = input(message)
if message == 'quit':
    active = False
else:
    print(message)
