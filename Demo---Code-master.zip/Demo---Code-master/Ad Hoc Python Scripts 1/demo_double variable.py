message = "Hello Python Crash Course"
print(message)

message = "Assalamu Alaikum Bilal...May Allah make learning how to program easy for you"
print(message)
