#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      HO0me
#
# Created:     29/05/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#, World!")
print("Hello Again")
print("I like typing this.")
print("This is fun.")
print('Yay! printing')
print("I'd much rather you 'not'.")
print('I "said" do not touch this!')
print('Getting started with Python...again!')
print('Gotta get this stuff learned')

