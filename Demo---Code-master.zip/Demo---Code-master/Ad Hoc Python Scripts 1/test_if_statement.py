name = input('Enter your name: ')

if name == 'Bilal' or 'ataa':
    print('Assalamu-Alaikum ' + name + '!')
else:
    print("I'm sorry you're not Bilal!")
