CountriesVisit = ["Saudi Arabia", "China", "Malaysia", "Argentina", "Brazil"]
print(CountriesVisit)
print(sorted(CountriesVisit))
print(CountriesVisit)

CountriesVisit.reverse()
print(CountriesVisit)
print(CountriesVisit)

CountriesVisit.reverse()
print(CountriesVisit)

CountriesVisit.sort()
print(CountriesVisit)

CountriesVisit.reverse()
CountriesVisit.sort()
print(CountriesVisit)

CountriesVisit.reverse()
print(CountriesVisit)

CountriesVisit.sort()
print(CountriesVisit)


