first_name = "Muhammad"
second_name = "Bilal"
full_name = first_name + " " + second_name
print("Asslamau-Alaikum, " + full_name)
