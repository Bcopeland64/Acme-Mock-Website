counts = dict()
names = ['csev', 'cwen', 'csev', 'zqain', 'cwen']
for name in names:
    counts[name]= counts.get(name, 0) + 1
print(counts)

counts = dict()
print('Enter a line of text:')
line = input()

words = line.split()

print('Words:', words)

print('Counting...')
for word in words:
    counts[word] = counts.get(word, 0) + 1
print('Counts', counts)