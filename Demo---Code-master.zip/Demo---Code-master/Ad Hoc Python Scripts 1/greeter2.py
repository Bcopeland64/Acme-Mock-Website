def greet_user(username):
    """Display a simple greeting."""
    print("Salaam Alaikum, " + username.title() + "!")
    
greet_user('Muhammad_Bilal')
