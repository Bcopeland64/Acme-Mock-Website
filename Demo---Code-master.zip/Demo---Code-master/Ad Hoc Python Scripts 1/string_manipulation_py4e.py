text = "X-DSPAM-Confidence:    0.8475";
x_text = text.find('0')
y_text = text[x_text:]
y_text = float(y_text)
print(y_text)

