numbers = [value**2 for value in range(1,200)]
print(numbers)

numbers = [value**3 for value in range(1,200)]
print(numbers)

odd_numbers = list(range(1,20))
print(odd_numbers)

odd_numbers = list(range(1,20))
for number in odd_numbers:
	print(number)

odd_numbers = list(range(3,20,3))
print(odd_numbers)

odd_numbers = list(range(1,10))
for number in odd_numbers:
	print(number**3)
	
odd_numbers = [value**3 for value in range(1,10)]
print(odd_numbers)
