def describe_car(company_type, model_type):
    """Display information about a car type"""
    print("\nI have a(n) " + company_type + ".")
    print("My " + company_type + "'s model is a(n) " + model_type.title() + ".")

describe_car('Chevrolet', 'Impala')
describe_car('Ford', 'Fairlane')
describe_car('Buick', 'Regal')
describe_car('Cadillac', 'Fleetwood')
describe_car('Oldsmobile', 'Cutlass Supreme')
describe_car('Chevrolet', 'El Camino')

print("\nAnd they all got triple-gold Daytons and Hydros!!!")
