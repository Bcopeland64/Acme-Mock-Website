#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      HO0me
#
# Created:     03/06/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------

print("How old are you?")
age = input()
print("How tall are you?")
height = input()
print("How much do you weigh?")
weight = input()

print(f"So, your {age} years old, {height} tall, and {weight} pounds.")


print("Where do you live?")
location = input()
print("What do you do?")
occupation = input()
print("How long have you been doing that?")
length = input()

print(f"So, you live in {location}, you work as a(n) {occupation}, and you've been doing that for {length} years.")

