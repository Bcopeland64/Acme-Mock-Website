prompt = "\nTell me what you would like on your pizza? "
prompt += "\nEnter 'quit' when you're done. "

message = ""
while message != 'quit':
    message = input(prompt)
    
if message != 'quit':
    print(message)
    

