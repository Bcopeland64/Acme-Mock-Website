def get_user(first_name, last_name):
    full_name = first_name + " " + last_name
    return full_name.title()

activist_leader = get_user('Malcolm', 'X')
print(activist_leader)
