#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      HO0me
#
# Created:     03/05/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------

#Google Search Multiple Sites:

import sys, requests, webbrowser, bs4

print('Googling...')
res = requests.get('http://google.com/search?q=' + ' '.join(sys.argv[1:]))
res.raise_for_status()

#Retrieve Top Results Links:
soup = bs4.BeautifulSoup(res.text, features="lxml")

#Open a browser tab for each result:
linkElems = soup.select('.r a')
NumOpen = min(5, len(linkElems))
for i in range(NumOpen):
    webbrowser.open('http://google.com' + linkElems[i].get('href'))

