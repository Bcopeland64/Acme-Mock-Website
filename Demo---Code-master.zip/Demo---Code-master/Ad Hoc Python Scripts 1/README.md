# Ad-Hoc-Python-Scripts

This folder contains scripts that I created from textbook exercises, tutorials, samples, courses, or other online materials.
