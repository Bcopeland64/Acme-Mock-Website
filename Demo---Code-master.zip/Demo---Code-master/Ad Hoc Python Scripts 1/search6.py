fname = input("Enter file name here: ")
try:
    fhand = open(fname)
except:
    print('File cannot be found: ', fname)
    exit()
for line in fhand:
    line = line.rstrip()
    count = count + 1
    print("There were", count, "lines in", fname)
