car = input("What kind of car would you like today? ")
print("Let's see if we can find you a " + car)
