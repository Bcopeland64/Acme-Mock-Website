buffet_items = ("Steak", "Potatoes", "Carrots", "Broccoli", "Cheesecake")
print("Buffet Items include: ")
for item in buffet_items:
	print(item)
	
buffet_items = ("Steak", "Potatoes", "Corn", "Asparagus", "Chocolate Cake")
print("Revised Buffet Items include: ")
for item in buffet_items:
	print(item)
