age = 21
if age >= 18:
    print("You're older than 18 years old")
    print("You're old enough to vote!")
    print("Have you registered to vote?")
else:
    print("You're younger than 18")
    print("Sorry...you're not old enough to vote")
    
