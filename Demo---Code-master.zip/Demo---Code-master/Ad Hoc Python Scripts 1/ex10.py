#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      HO0me
#
# Created:     01/06/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------

tabby_cat = "\tI'm tabbed in."
persian_cat = "I'm split\non a line."
backslash_cat = "I'm \\ a \\ cat."

fat_cat = """I'll do a list:
    \t* Cat food
    \t* Fishies
    \t* Catnip
    \t* Grass
    """

print(tabby_cat)
print(persian_cat)
print(backslash_cat)
print(fat_cat)
