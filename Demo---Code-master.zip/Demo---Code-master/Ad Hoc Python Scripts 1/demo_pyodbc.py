import pyodbc

mydb = pyodbc.connect(
  host="localhost",
)

print(mydb)
