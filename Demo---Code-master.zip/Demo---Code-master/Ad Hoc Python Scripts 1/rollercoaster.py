height = input("How tall are you, in inches? ")
height = int(height)

if height >= 36:
    print("\nYou are tall enough to ride this ride!")
else:
    print("Sorry!...You'll have to wait until you're a little taller")
