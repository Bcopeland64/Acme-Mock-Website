favorite_number = {'Ataa': '2', 'Bilal': '64', 'Maram': '7', 'Manal': '14', 
    'Damla': '57', 'Jahangir': '21'}
print("Ataa's favorite number is " + favorite_number['Ataa'] + ".")
print("Bilal's favorite number is " + favorite_number['Bilal'] + ".")
print("Maram's favorite number is " + favorite_number['Maram'] + ".")
print("Manal's favorite number is " + favorite_number['Manal'] + ".")
print("Damla's favorite number is " + favorite_number['Damla'] + ".")
print("Jahangir's favorite number is " + favorite_number['Jahangir'] + ".")

