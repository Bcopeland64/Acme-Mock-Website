age = 43
message = "Happy, " + str(age) + "rd Birthday!"
print(message)
