#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      HO0me
#
# Created:     29/05/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------
# This prints that following string
print("I will count my chickens: ")
#This prints the number of hens and roosters
print("Hens", 25 + 30 / 6)
print("Roosters", 100 - 25 * 3 % 4)
#This asks the question below
print("Now I will count the eggs: ")
#This statement will add, subtract, multiply, or divide the following
print(3 + 2 + 1 - 5 + 4 % 2 - 1 / 4 + 6)
#This prints the following question
print("Is it true that 3 + 2 < 5 -7?")
#This prints the product of the following equation
print(3 + 2 < 5 - 7)
#This prints the following questions with the answers
print("What is 3 + 2?", 3 + 2)
print("What is 5 - 7?", 5 - 7)
#This prints the following questions
print("Oh! That's why it's false")
print("How about some more?")
#This prints the following questions with the answers to (Boolean) questions
print("Is is greater?", 5 > -2)
print("Is it greater or equal?", 5 >= -2)
print("Is it less or equal?", 5 <= -2)


