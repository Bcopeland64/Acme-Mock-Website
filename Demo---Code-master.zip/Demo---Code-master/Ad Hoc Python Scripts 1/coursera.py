#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      HO0me
#
# Created:     08/06/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------

hrs = input("Enter Hours:")
h = float(hrs)
pay_rate = 10.50

if h <= 40:
    pay = h * r
else:
    if h > 40:
        pay = 40 * pay_rate + (h-40) * 1.5 * pay_rate

print(pay)