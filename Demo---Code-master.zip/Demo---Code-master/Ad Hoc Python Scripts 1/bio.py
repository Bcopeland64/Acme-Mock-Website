#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      HO0me
#
# Created:     29/05/2019
# Copyright:   (c) HO0me 2019
# Licence:     <your licence>
#-------------------------------------------------------------------------------

name = 'Muhammad Bilal'
age = 42
height = 74 * 2.54
weight = 380 / 0.45
eyes = 'Brown'
teeth = 'White'
hair = 'Black'

print(f"Let's talk about {name}.")
print(f"He's " + str(round(height)) + " centimeters tall.")
print(f"He's " + str(round(weight)) + " kilos heavy.")
print(f"Actually, that's very heavy!")
print(f"He's got {eyes} eyes and {hair} hair.")
print(f"His teeth are usually {teeth} depending on the coffee.")

total = my_age + my_height + my_weight
print(f"If I add {age}, " + str(round(height)) + " and " +  str(round(weight)) + " I get {total}.")
