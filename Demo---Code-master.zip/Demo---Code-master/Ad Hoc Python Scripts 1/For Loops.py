#Make sure you memorize the syntax for "for" loops here. This will be a valuable syntax for upcoming projects
leaders = ["Malcolm X", "Marcus Garvey", "Bobby Seale", "Huey Newton", "Imam Siraj Wahhaj"]
for leader in leaders:
  print(leader.title() + ", you lead nations of Black Americans")
  print("We need more leaders like you in the Black Community, " + leader.title() + ".\n")
print("We ask Allah to bless us with more men like you")
