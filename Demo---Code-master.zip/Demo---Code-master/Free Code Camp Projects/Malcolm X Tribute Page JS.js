// coded by @Cope With It Development
const projectName = 'tribute-page';
localStorage.setItem('example_project', 'Tribute Page');