# Demo---Code

A friendly little place for all of my practice scripts including games, blogs with Django, as well as other minimal applications.
