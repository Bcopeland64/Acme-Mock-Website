# Alien-Invasion


This is a small Python game where players shoot down invading aliens. This game was made following the "Python Crash Course" project at the end of the text.

All game components are located in this folder.
