# Data-Visualization-Project


Series of Data Visualizations using primarily Matplotlib and Pygal to plot various census/population data.
