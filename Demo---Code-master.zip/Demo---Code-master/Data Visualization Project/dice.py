# -*- coding: utf-8 -*-
"""
Created on Sat Apr 20 20:08:01 2019

@author: HO0me
"""

from random import randint

class Die():
    """A class representing a single die."""
    
    def __init__(self, num_sides=6):
        """Assume a six-sided die."""
        self.num_sides = num_sides
        
    def roll(self):
        """Return random value between 1 and number of sides."""
        return randint(1, self.num_sides)