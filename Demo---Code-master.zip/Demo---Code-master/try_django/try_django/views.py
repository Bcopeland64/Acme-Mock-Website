from django.http import HttpResponse
from django.shortcuts import render

def home_page(request):
    return render(request, "base1.html")

def about_page(request):
    return render(request, "about_us.html")

def contact_page(request):
    return HttpResponse(request, "contact_us.html")
